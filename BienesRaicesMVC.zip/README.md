# Bienes-Raices-Web
Proyecto enfocado a bienes raices y la oportunidad de simplificar los procesos, en el cual se ofrece contactarte con un agente especializado para la compra de una de las casas o venta de tu propiedad.
