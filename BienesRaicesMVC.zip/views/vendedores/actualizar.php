<main class="contenedor">
    <h1>Actualizar vendedor(a)</h1>

    <a href="/admin" class="boton boton-naranja">Volver</a>

    <form class="formulario formulario-crear" method="POST">

    <?php 
        include 'formulario.php'
    ?>

    <input type="submit" value="Guardar cambios" class="boton boton-verde">

    </form>

</main>