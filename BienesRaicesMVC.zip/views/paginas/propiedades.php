<main class="contenedor">

    <section class="seccion contenedor padding-titulos">
        <h1>Casas y departamentos en venta</h1>

        <?php
            include 'listado.php';
        ?>

</main>