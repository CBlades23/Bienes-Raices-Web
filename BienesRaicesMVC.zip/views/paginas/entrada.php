<main class="contenedor seccion contenido-centrado">
    <h1>Guía para decoración de tu hogar</h1>

    <picture class="imagen">
        <source srcset="build/img/destacada2.webp" type="image/webp">
        <source srcset="build/img/destacada2.jpg" type="image/jpeg">
        <img loading="lazy" src="build/img/destacada2.jpg" alt="Texto entrada blog">
    </picture>

    <p class="informacion-meta">Escrito el: <span>25/11/2022</span> por: <span>Admin</span></p>

    <div class="resumen-propiedad">

        <p class="descripcion">Lorem ipsum dolor sit amet consectetur, adipisicing elit. Impedit voluptatibus, dolor consequatur laborum amet consequuntur, voluptatem sit deserunt dicta accusamus atque exercitationem corporis, libero tempora aspernatur quod nobis aliquam ducimus. Voluptatem sit deserunt dicta accusamus atque exercitationem corporis, libero tempora aspernatur quod nobis aliquam ducimus. Voluptatem sit deserunt dicta accusamus atque exercitationem corporis, libero tempora aspernatur quod nobis aliquam ducimus Voluptatem sit deserunt dicta accusamus atque exercitationem corporis, libero tempora aspernatur quod nobis aliquam ducimus.</p>

        <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Impedit voluptatibus, dolor consequatur laborum amet consequuntur, voluptatem sit deserunt dicta accusamus atque exercitationem corporis, libero tempora aspernatur quod nobis aliquam ducimus. Voluptatem sit deserunt dicta accusamus atque exercitationem corporis, libero tempora aspernatur quod nobis aliquam ducimus. </p>

    </div>
</main>