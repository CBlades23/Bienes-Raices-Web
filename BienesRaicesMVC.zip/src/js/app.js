document.addEventListener('DOMContentLoaded', function(){

    eventListener();

    darkMode();
});

/*Dark Mode - elegir tipo de modo según su preferencia en windows*/

function darkMode() {

    const prefiereDarkMode = window.matchMedia('(prefers-color-scheme: dark)'); 
    console.log(prefiereDarkMode.matches);

    if (prefiereDarkMode.matches) {
        document.body.classList.add('dark-mode');
    }else {
        document.body.classList.remove('dark-mode');
    }

    prefiereDarkMode.addEventListener('change', function() {
        if (prefiereDarkMode.matches) {
            document.body.classList.add('dark-mode');
        }else {
            document.body.classList.remove('dark-mode');
        }
    });

    const botonDarkMode = document.querySelector('.dark-mode-boton');

    botonDarkMode.addEventListener('click', function(){
        document.body.classList.toggle('dark-mode');
    })
}

/*Nav del Menu para Mobile*/

function eventListener() {
    const mobileMenu = document.querySelector('.mobile-menu');

    mobileMenu.addEventListener('click', navegacionResponsive);

    //Muestra campos condicionales
    const metodoContacto = document.querySelectorAll('input[name="contacto[contacto]"]');

    metodoContacto.forEach(input => input.addEventListener('click', mostrarMetodos)); 
}

function navegacionResponsive() {
    const navegacion = document.querySelector('.navegacion');

    navegacion.classList.toggle('mostrar')
}

function mostrarMetodos(e) {
    const contactoDiv = document.querySelector('#contacto');
    
    if (e.target.value === 'telefono') {
        contactoDiv.innerHTML = `
            <label for="telefono">Número de  Telefono</label>
            <input type="tel" placeholder="Tu telefono" id="telefono" name="contacto[telefono]">

            <p>Elija la fecha y hora para la llamada.</p>

            <label for="fecha">fecha</label>
            <input type="date" id="fecha" name="contacto[fecha]">

            <label for="hora">Hora</label>
            <input type="time" id="hora" min="09:00" max="07:00" name="contacto[hora]">
        `;
    } else {
        contactoDiv.innerHTML = `
            <label for="email">E-mail</label>
            <input type="email" placeholder="Tu email" id="email" name="contacto[email]" >

        `;
    }
}


/*Alerta para cuando se hace alguna acción (CREAR, ELIMINAR, ACTUALIZAR) en Admin*/
document.addEventListener('DOMContentLoaded', function () {
	mensajesTime();
});

function mensajesTime() {
	if (document.querySelector('.alerta')) {
		//Eliminar texto de confirmación de CRUD en admin
		setInterval(function () {
			const mensajeConfirm = document.querySelector('.alerta');
			const padre = mensajeConfirm.parentElement;
			padre.removeChild(mensajeConfirm);
		}, 3500);
	}
}